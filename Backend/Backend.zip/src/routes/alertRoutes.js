import express from 'express';
import { getAlerts, markAsRead, markAsResolved, createAlert, getUnreadCount, deleteAlert } from '../controllers/alertController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

router.use(authenticateToken);

router.get('/', getAlerts);
router.get('/unread-count', getUnreadCount);
router.put('/:id/read', markAsRead);
router.put('/:id/resolve', markAsResolved);
router.delete('/:id', deleteAlert);
router.post('/', createAlert);

export default router;
